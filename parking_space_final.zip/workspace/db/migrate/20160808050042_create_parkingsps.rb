class CreateParkingsps < ActiveRecord::Migration
  def change
    create_table :parkingsps do |t|
      t.string :placa
      t.integer :usuario_id
      t.string :distrito
      t.date :dia
      t.time :horario
      t.integer :horas
      t.decimal :monto

      t.timestamps null: false
    end
  end
end
