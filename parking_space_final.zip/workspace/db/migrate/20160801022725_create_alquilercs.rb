class CreateAlquilercs < ActiveRecord::Migration
  def change
    create_table :alquilercs do |t|
      t.integer :cochera
      t.string :datos
      t.string :distrito
      t.string :direccion
      t.decimal :precio
      t.string :nrotelefono
      t.string :movil
      t.string :correo
      t.string :observaciones

      t.timestamps null: false
    end
  end
end
