require 'test_helper'

class AlquilercsControllerTest < ActionController::TestCase
  setup do
    @alquilerc = alquilercs(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:alquilercs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create alquilerc" do
    assert_difference('Alquilerc.count') do
      post :create, alquilerc: { cochera: @alquilerc.cochera, correo: @alquilerc.correo, datos: @alquilerc.datos, direccion: @alquilerc.direccion, distrito: @alquilerc.distrito, movil: @alquilerc.movil, nrotelefono: @alquilerc.nrotelefono, observaciones: @alquilerc.observaciones, precio: @alquilerc.precio }
    end

    assert_redirected_to alquilerc_path(assigns(:alquilerc))
  end

  test "should show alquilerc" do
    get :show, id: @alquilerc
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @alquilerc
    assert_response :success
  end

  test "should update alquilerc" do
    patch :update, id: @alquilerc, alquilerc: { cochera: @alquilerc.cochera, correo: @alquilerc.correo, datos: @alquilerc.datos, direccion: @alquilerc.direccion, distrito: @alquilerc.distrito, movil: @alquilerc.movil, nrotelefono: @alquilerc.nrotelefono, observaciones: @alquilerc.observaciones, precio: @alquilerc.precio }
    assert_redirected_to alquilerc_path(assigns(:alquilerc))
  end

  test "should destroy alquilerc" do
    assert_difference('Alquilerc.count', -1) do
      delete :destroy, id: @alquilerc
    end

    assert_redirected_to alquilercs_path
  end
end
