require 'test_helper'

class ParkingspsControllerTest < ActionController::TestCase
  setup do
    @parkingsp = parkingsps(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:parkingsps)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create parkingsp" do
    assert_difference('Parkingsp.count') do
      post :create, parkingsp: { dia: @parkingsp.dia, distrito: @parkingsp.distrito, horario: @parkingsp.horario, horas: @parkingsp.horas, monto: @parkingsp.monto, placa: @parkingsp.placa, usuario_id: @parkingsp.usuario_id }
    end

    assert_redirected_to parkingsp_path(assigns(:parkingsp))
  end

  test "should show parkingsp" do
    get :show, id: @parkingsp
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @parkingsp
    assert_response :success
  end

  test "should update parkingsp" do
    patch :update, id: @parkingsp, parkingsp: { dia: @parkingsp.dia, distrito: @parkingsp.distrito, horario: @parkingsp.horario, horas: @parkingsp.horas, monto: @parkingsp.monto, placa: @parkingsp.placa, usuario_id: @parkingsp.usuario_id }
    assert_redirected_to parkingsp_path(assigns(:parkingsp))
  end

  test "should destroy parkingsp" do
    assert_difference('Parkingsp.count', -1) do
      delete :destroy, id: @parkingsp
    end

    assert_redirected_to parkingsps_path
  end
end
