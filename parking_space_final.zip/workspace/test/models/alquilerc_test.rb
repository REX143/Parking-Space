require 'test_helper'

class AlquilercTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
