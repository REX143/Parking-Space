require 'test_helper'

class ParkingspTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
