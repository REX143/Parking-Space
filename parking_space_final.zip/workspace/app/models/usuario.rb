class Usuario < ActiveRecord::Base
    has_many :parkingsp
    validates :usuario, uniqueness: {message: "Usuario ya registrado"}, presence:{message: "Por favor ingresar sus nombres"} 
    validates :correo, presence:{message: "Ingresar un correo para enviarle la confirmación"} 
    validates :telefono,presence:{message: "Por favor ingresar un número"} 
    
end
