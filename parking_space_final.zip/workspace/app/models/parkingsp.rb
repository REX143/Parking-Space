class Parkingsp < ActiveRecord::Base
    
    belongs_to :usuario
    validates :usuario_id,presence:{message: "Por favor registrar al usuario_i"} 
    validates :placa,uniqueness: {message: "Estacionamiento reservado"}, presence:{message: "Ingresar el Nro de placa para reservar el estacionamiento"} 
    
    
end
