module WarehousesHelper
end
