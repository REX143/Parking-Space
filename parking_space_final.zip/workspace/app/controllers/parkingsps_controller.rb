class ParkingspsController < ApplicationController
  before_action :set_parkingsp, only: [:show, :edit, :update, :destroy]

  # GET /parkingsps
  # GET /parkingsps.json
  def index
    @parkingsps = Parkingsp.all
  end

  # GET /parkingsps/1
  # GET /parkingsps/1.json
  def show
  end

  # GET /parkingsps/new
  def new
    @parkingsp = Parkingsp.new
  end

  # GET /parkingsps/1/edit
  def edit
  end

  # POST /parkingsps
  # POST /parkingsps.json
  def create
    @parkingsp = Parkingsp.new(parkingsp_params)

    respond_to do |format|
      if @parkingsp.save
        format.html { redirect_to @parkingsp, notice: 'Parkingsp was successfully created.' }
        format.json { render :show, status: :created, location: @parkingsp }
      else
        format.html { render :new }
        format.json { render json: @parkingsp.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /parkingsps/1
  # PATCH/PUT /parkingsps/1.json
  def update
    respond_to do |format|
      if @parkingsp.update(parkingsp_params)
        format.html { redirect_to @parkingsp, notice: 'Parkingsp was successfully updated.' }
        format.json { render :show, status: :ok, location: @parkingsp }
      else
        format.html { render :edit }
        format.json { render json: @parkingsp.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /parkingsps/1
  # DELETE /parkingsps/1.json
  def destroy
    @parkingsp.destroy
    respond_to do |format|
      format.html { redirect_to parkingsps_url, notice: 'Parkingsp was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_parkingsp
      @parkingsp = Parkingsp.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def parkingsp_params
      params.require(:parkingsp).permit(:placa, :usuario_id, :distrito, :dia, :horario, :horas, :monto)
    end
end
