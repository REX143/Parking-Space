class AlquilercsController < ApplicationController
  before_action :set_alquilerc, only: [:show, :edit, :update, :destroy]

  # GET /alquilercs
  # GET /alquilercs.json
  def index
    @alquilercs = Alquilerc.all
  end

  # GET /alquilercs/1
  # GET /alquilercs/1.json
  def show
  end

  # GET /alquilercs/new
  def new
    @alquilerc = Alquilerc.new
  end

  # GET /alquilercs/1/edit
  def edit
  end

  # POST /alquilercs
  # POST /alquilercs.json
  def create
    @alquilerc = Alquilerc.new(alquilerc_params)

    respond_to do |format|
      if @alquilerc.save
        format.html { redirect_to @alquilerc, notice: 'Alquilerc was successfully created.' }
        format.json { render :show, status: :created, location: @alquilerc }
      else
        format.html { render :new }
        format.json { render json: @alquilerc.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /alquilercs/1
  # PATCH/PUT /alquilercs/1.json
  def update
    respond_to do |format|
      if @alquilerc.update(alquilerc_params)
        format.html { redirect_to @alquilerc, notice: 'Alquilerc was successfully updated.' }
        format.json { render :show, status: :ok, location: @alquilerc }
      else
        format.html { render :edit }
        format.json { render json: @alquilerc.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /alquilercs/1
  # DELETE /alquilercs/1.json
  def destroy
    @alquilerc.destroy
    respond_to do |format|
      format.html { redirect_to alquilercs_url, notice: 'Alquilerc was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_alquilerc
      @alquilerc = Alquilerc.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def alquilerc_params
      params.require(:alquilerc).permit(:cochera, :datos, :distrito, :direccion, :precio, :nrotelefono, :movil, :correo, :observaciones)
    end
end
