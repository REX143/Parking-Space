class Alquilerc < ActiveRecord::Base
    validates :cochera, uniqueness: {message: "No puede ser repetido"}, presence:{message: "Ingresar dato obligatorio"} 
    validates :distrito, presence:{message: "Deberá indicar el distrito"} 
    validates :direccion,presence:{message: "Por favor ingrese su dirección"} 
    validates :nrotelefono, presence:{message: "Debe dejar un número de contacto"} 


end
